from setuptools import setup, find_packages

setup(
    name="elasticsearchDemo",
    version="1.0",
    author="wangdi",
    author_email="diwang839639311@163.com",
    description="elasticsearchDemo",

    # 你要安装的包，通过 setuptools.find_packages 找到当前目录下有哪些包
    packages=find_packages()
)
